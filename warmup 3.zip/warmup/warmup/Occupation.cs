﻿using System;
namespace warmup
{
    public class Occupation
    {
        public string Title;

        public Occupation(string _title)
        {
            Title = _title;
        }


    }
}
